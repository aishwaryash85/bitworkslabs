<template>
  <q-table></q-table>
</template>
