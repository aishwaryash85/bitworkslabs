<template>
  <q-form>
     <q-input  v-model="inputValue" :rules="[validation]"></q-input>
  </q-form>
</template>
<script>
export default {
  data() {
    return {
      inputValue: null
    }
  },
  methods: {
    checkValidation
  }

}
</script>
