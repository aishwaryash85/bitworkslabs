<template>
  <q-card class="q-pa-md q-ma-md">
    {{ formData }}
    <div class="column">
      <q-input v-model="formData.id" label="ID" />
      <q-input v-model="formData.account_name" label="Account Name" />
      <q-input v-model="formData.account_address" label="Account Address" type="text" />
      <q-input v-model="formData.contact_number" label="Contact Number" />
      <q-input v-model="formData.email" label="Email" />
      <q-input v-model="formData.city" label="City" />
      <q-input v-model="formData.state" label="State" />
      <q-input v-model="formData.pin_code" label="Pin Code" />
      <q-input v-model="formData.country" label="Country" />
      <q-input v-model="formData.accounting_receipts" label="Accounting Receipts" />
      <q-select v-model="formData.status" label="Status" :options="['Published','Draft','Archived']"
       option-label="Standard"  />
      <q-input v-model="formData.user_created" label="User Created" />
      <q-input v-model="formData.date_created" label="Date_created" />
      <q-input v-model="formData.user_updated" label="User Updated" />
      <q-input v-model="formData.data_updated" label="Date Updated" />
      <q-input v-model="formData.invoices" label="Invoices" />
      <q-input v-model="formData.contacts" label="Contacts" />
      <q-input v-model="formData.log_book" label="Log Book" />
      <q-input v-model="formData.contracts" label="Contracts" />
      <q-input v-model="formData.gst" label="GST" />
      <q-input v-model="formData.date_created" label="Date Created" >
      <template v-slot:prepend>
      <q-icon name="schedule" class="cursor-pointer">
      <q-popup-proxy cover transition-show="scale" transition-hide="scale">
      <q-time v-model="formData.date_created" mask="YYYY-MM-DD HH:mm">
      <div class="row items-center justify-end">
      <q-btn v-close-popup label="close" color="red" flat />
      </div>
      </q-time>
      </q-popup-proxy> </q-icon>
      </template>
      <template v-slot:append>
      <q-icon name="event" class="cursor-pointer">
      <q-popup-proxy cover transition-show="scale" transition-hide="scale">
      <q-date v-model="formData.date_created" mask="YYYY-MM-DD HH:mm">
      <div class="row items-center  justify-end">
      <q-btn v-close-popup label="close" color="teal" flat/>
      </div>
      </q-date>
      </q-popup-proxy>
      </q-icon>
      </template>
      </q-input>
      <q-input v-model="formData.date_updated" label="Date Updated" />
    </div>
    <div class="q-py-md">
      <q-btn color="red" label="submit" @click="submitData"></q-btn>
    </div>
    <div class="q-py-md">
      <q-btn color="red" label="close" to="./"></q-btn>
    </div>
  </q-card>

</template>
<script>
export default {
  data () {
    return {
      formData: {}
    }
  },
  methods: {
    submitData () {
      console.log('Emitting Event of submitting form with data')
      alert()
      this.$emit('formSubmit', this.formData)
      console.log('Resetting Form')
      alert()
      this.formData = {}
    }
  }
}
</script>
